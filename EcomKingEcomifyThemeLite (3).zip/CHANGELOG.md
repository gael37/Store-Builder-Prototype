# Change Log

## [1.1.0] - 2023-10-01
- Size chart option in PDP #2
- Add styling support for Judgme and Loox review apps #3

## [1.0.0] - 2023-07-01